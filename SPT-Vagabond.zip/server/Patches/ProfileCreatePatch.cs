using System.Reflection;
using SPTarkov.Reflection.Patching;
using SPTarkov.Server.Core.Models.Common;
using SPTarkov.Server.Core.Models.Eft.Profile;
using SPTarkov.Server.Core.Services;
using Vagabond.Common.Data;
using Vagabond.Server.Services;
using Vagabond.Server.State;

namespace Vagabond.Server.Patches;

public sealed class ProfileCreatePatch : AbstractPatch
{
    protected override MethodBase GetTargetMethod()
    {
        return typeof(CreateProfileService).GetMethod(nameof(CreateProfileService.CreateProfile))!;
    }

    [PatchPostfix]
    public static void Postfix(MongoId sessionId, ref ValueTask<string> __result)
    {
        __result = RunAfterCreate(__result, sessionId);
    }

    private static async ValueTask<string> RunAfterCreate(ValueTask<string> original, MongoId sessionId)
    {
        string profileId = await original.ConfigureAwait(false);
        CreateProfile(sessionId);
        return profileId;
    }

    public static void CreateProfile(MongoId sessionId)
    {
        if (!VagabondService.ShouldApplyVagabondRules(sessionId))
        {
            return;
        }

        var pmc = VagabondService.GetPmcProfile(sessionId);
        if (pmc?.CharacterData?.PmcData == null)
        {
            VagabondLogger.Error($"BootstrapProfile did not modify profile for {sessionId}; PMC null {sessionId}");
            return;
        }

        var changed = InitializeNewCharacter(sessionId, pmc);
        if (!changed)
        {
            VagabondLogger.Error(
                $"BootstrapProfile did not modify profile for {sessionId}; InitializeNewCharacter did not complete.");
            return;
        }

        var state = VagabondState.GetState(sessionId);
        state.VagabondModeEnabled = true;
        VagabondState.SaveState(sessionId, state);
        HideoutService.UpdateTraderAccess(pmc.CharacterData.PmcData, state);
        VagabondService.PersistProfileIfPossible(sessionId);
        MailerService.SendMail(sessionId, Messages.WelcomeOpenWorld());
        VagabondLogger.Success($"activated Vagabond profile for {sessionId}.");
    }

    private static bool InitializeNewCharacter(MongoId sessionId, SptProfile pmc)
    {
        if (pmc.CharacterData?.PmcData == null)
        {
            VagabondLogger.Error("InitializeNewCharacter: PmcData was null.");
            return false;
        }

        var inventory = pmc.CharacterData.PmcData.Inventory;
        if (inventory == null)
        {
            VagabondLogger.Error("InitializeNewCharacter: inventory was null.");
            return false;
        }

        var items = inventory.Items;
        if (items == null)
        {
            VagabondLogger.Error("InitializeNewCharacter: inventory items list was null.");
            return false;
        }

        VagabondService.WipeItems(sessionId, pmc.CharacterData.PmcData, true, true);
        VagabondService.AddMoney(sessionId, pmc.CharacterData.PmcData);
        return true;
    }
}