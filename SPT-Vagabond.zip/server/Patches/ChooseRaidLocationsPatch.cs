using System.Reflection;
using System.Text.Json.Nodes;
using SPTarkov.Reflection.Patching;
using SPTarkov.Server.Core.Callbacks;
using SPTarkov.Server.Core.Models.Common;
using Vagabond.Common.Data;
using Vagabond.Common.Models;
using Vagabond.Common.Enums;
using Vagabond.Server.Config;
using Vagabond.Server.Services;
using Vagabond.Server.State;

namespace Vagabond.Server.Patches;

public sealed class ChooseRaidLocationsPatch : AbstractPatch
{
    protected override MethodBase GetTargetMethod()
    {
        return typeof(LocationCallbacks).GetMethod(nameof(LocationCallbacks.GetLocationData))!;
    }

    [PatchPostfix]
    public static void Postfix(MongoId sessionID, ref ValueTask<string> __result)
    {
        var serverOwnerSessionId = FikaAdapter.GetRaidOwnerSessionId(sessionID);
        __result = RewriteResponseAsync(serverOwnerSessionId, __result);
    }

    private static async ValueTask<string> RewriteResponseAsync(MongoId sessionId, ValueTask<string> originalResult)
    {
        string jsonString = await originalResult;

        JsonNode? root = JsonNode.Parse(jsonString);
        if (root is null)
        {
            return jsonString;
        }

        if (!VagabondService.ShouldApplyVagabondRules(sessionId))
        {
            return jsonString;
        }

        var pmc = VagabondService.GetPmcProfile(sessionId);
        if (pmc == null || pmc.CharacterData?.PmcData == null)
        {
            VagabondLogger.Error($"Raid extractions: could not resolve PMC profile for {sessionId}.");
            return jsonString;
        }

        var state = VagabondState.GetState(sessionId);
        if (!state.VagabondModeEnabled)
        {
            VagabondLogger.Error($"Missing state {sessionId}.");
            return jsonString;
        }

        if (string.IsNullOrEmpty(state.CurrentMap) || VagabondConfig.Config.EnablePickRaidLocation)
        {
            return jsonString;
        }

        RaidLocation currentMap = VagabondLocations.NormaliseMapName(state.CurrentMap);
        if (currentMap == RaidLocation.Nil)
        {
            return jsonString;
        }
        
        JsonObject? data = root["data"]?.AsObject();
        JsonObject? locations = data?["locations"]?.AsObject();

        if (locations == null)
        {
            VagabondLogger.Error($"locations is null {sessionId}.");
            return jsonString;
        }
        HashSet<string> allowedMapIds = new(StringComparer.OrdinalIgnoreCase);
        
        RaidLocation transitMap = VagabondLocations.NormaliseMapName(state.TransitState?.ToMap);
        if (transitMap != RaidLocation.Nil)
        {
            if (VagabondLocations.Locations.TryGetValue(transitMap, out var mapIds))
            {
                foreach (var mapId in mapIds)
                {
                    allowedMapIds.Add(mapId);
                }
            }
        }
        else
        {
            if (VagabondLocations.Locations.TryGetValue(currentMap, out var mapIds))
            {
                foreach (var mapId in mapIds)
                {
                    allowedMapIds.Add(mapId);
                }
            }
        }

        if (allowedMapIds.Count == 0)
        {
            return jsonString;
        }
        
        foreach (string locationKey in locations.Select(kv => kv.Key).ToList())
        {
            if (!allowedMapIds.Contains(locationKey))
            {
                JsonObject? location = locations[locationKey]?.AsObject();
                if (location != null)
                {
                    location["enabled"] = false;
                }
            }
        }

        foreach (string locationKey in locations.Select(x => x.Key).ToList())
        {
            JsonObject? location = locations[locationKey]?.AsObject();
            JsonArray? exits = location?["exits"]?.AsArray();
            JsonArray? secretExits = location?["secretExits"]?.AsArray();
            bool enabled = location?["enabled"]?.GetValue<bool>() ?? true;

            if (!enabled)
            {
                continue;
            }

            if (exits != null)
            {
                for (int i = exits.Count - 1; i >= 0; i--)
                {
                    JsonObject? exfil = exits[i]?.AsObject();

                    if (exfil is null)
                    {
                        exits.RemoveAt(i);
                        continue;
                    }

                    if (!IsCustomExtract(exfil, locationKey))
                    {
                        exits.RemoveAt(i);
                    }
                }
            }

            if (secretExits != null)
            {
                secretExits.Clear();
            }
        }

        return root.ToJsonString(new System.Text.Json.JsonSerializerOptions
        {
            WriteIndented = false
        });
    }

    private static bool IsCustomExtract(JsonObject exfil, MongoId locationKey)
    {
        string? name = exfil["Name"]?.GetValue<string>();
        var raid = VagabondLocations.NormaliseMapName(locationKey);
        if (!VagabondLocations.IdToName.TryGetValue(locationKey, out var mapName))
        {
            return false;
        }
        
        return ExfilService.IsCustomExtractName(name, raid, mapName);
    }
}
