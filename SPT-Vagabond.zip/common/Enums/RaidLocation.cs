using System.ComponentModel;

namespace Vagabond.Common.Enums;

public enum RaidLocation
{
    Nil,
    FactoryDay,
    FactoryNight,
    [Description("Ground Zero")] GroundZero,
    Streets,
    Woods,
    Customs,
    Interchange,
    Lighthouse,
    Reserve,
    Shoreline,
    Labs,
    Labyrinth
}