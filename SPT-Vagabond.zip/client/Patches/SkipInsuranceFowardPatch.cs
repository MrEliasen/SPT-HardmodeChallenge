﻿using System;
using System.Reflection;
using EFT.HealthSystem;
using EFT.InventoryLogic;
using EFT.UI.Matchmaker;
using HarmonyLib;
using SPT.Reflection.Patching;

namespace Vagabond.Client.Patches
{
    internal class SkipInsuranceScreenPatch : ModulePatch
    {
        protected override MethodBase GetTargetMethod()
        {
            var method = typeof(MatchmakerInsuranceScreen).GetMethod(
                "Show",
                BindingFlags.Instance | BindingFlags.Public,
                Type.DefaultBinder,
                new[]
                {
                    typeof(MatchmakerInsuranceScreen.GClass3913)
                },
                null
            );

            return method!;
        }

        [PatchPostfix]
        private static void Postfix(MatchmakerInsuranceScreen __instance)
        {
            Vagabond.Log($"SkipInsurance hit");
            var screenControllerField = AccessTools.Field(__instance.GetType(), "ScreenController");
            var screenController = screenControllerField?.GetValue(__instance);
            if (screenController == null)
            {
                Vagabond.Log($"SkipInsurance hit: screenController is null");
                return;
            }

            var showNextScreen = AccessTools.Method(screenController.GetType(), "ShowNextScreen");
            if (showNextScreen == null)
            {
                Vagabond.Log($"SkipInsurance hit: showNextScreen is null");
                return;
            }

            showNextScreen.Invoke(screenController, null);
        }
    }
    
    internal class SkipInsuranceScreenPatch2 : ModulePatch
    {
        protected override MethodBase GetTargetMethod()
        {
            return AccessTools.Method(
                typeof(MatchmakerInsuranceScreen),
                "Show",
                new[]
                {
                    typeof(AbstractQuestControllerClass),
                    typeof(IHealthController),
                    typeof(InventoryController),
                    typeof(ISession)
                });
        }

        [PatchPostfix]
        private static void Postfix(MatchmakerInsuranceScreen __instance)
        {
            var screenControllerField = AccessTools.Field(__instance.GetType(), "ScreenController");
            var screenController = screenControllerField?.GetValue(__instance);
            if (screenController == null)
            {
                Vagabond.Log($"SkipInsurance hit: screenController is null");
                return;
            }

            var showNextScreen = AccessTools.Method(screenController.GetType(), "ShowNextScreen");
            if (showNextScreen == null)
            {
                Vagabond.Log($"SkipInsurance hit: showNextScreen is null");
                return;
            }

            showNextScreen.Invoke(screenController, null);
        }
    }
}